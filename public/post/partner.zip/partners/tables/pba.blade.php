<div class="box box-primary pbabox">
    <h4><i class="fas fa-piggy-bank"></i> Bankszámlák</h4>
    <div class="box-body"  >
        <table class="table table-hover table-bordered pba-table" style="width: 100%;"></table>
    </div>
</div>

