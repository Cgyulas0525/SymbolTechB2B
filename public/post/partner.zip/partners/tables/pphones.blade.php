<div class="box box-primary pphonesbox">
    <h4><i class="fas fa-phone"></i> Telefonszám</h4>
    <div class="box-body"  >
        <table class="table table-hover table-bordered pphones-table" style="width: 100%;"></table>
    </div>
</div>
