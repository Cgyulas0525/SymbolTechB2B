<div class="box box-primary pptsbox">
    <h4><i class="fas fa-people-arrows"></i>Típus</h4>
    <div class="box-body"  >
        <table class="table table-hover table-bordered ppts-table" style="width: 100%;"></table>
    </div>
</div>
