<div class="box box-primary paddressbox">
    <h4><i class="fas fa-landmark"></i> Cím</h4>
    <div class="box-body"  >
        <table class="table table-hover table-bordered paddress-table" style="width: 100%;"></table>
    </div>
</div>
