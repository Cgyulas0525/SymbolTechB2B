<div class="box box-primary pemailsbox">
    <h4><i class="fas fa-envelope-open"></i> Email</h4>
    <div class="box-body"  >
        <table class="table table-hover table-bordered pemails-table" style="width: 100%;"></table>
    </div>
</div>
