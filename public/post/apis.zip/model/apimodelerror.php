<?php

class apimodelerror
{
    public $id;
    public $apimodel_id;
    public $smtp;
    public $error;
    public $created_at;
    public $updated_at;
    public $deleted_at;
}
